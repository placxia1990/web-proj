package com.model;

import java.util.Date;

public class Review {
	Date rvwDate;
	int rvwCleaness;
	int rvwService;
	int rvwStaff;
	int rvwLocation;
	int rvwMoney;
	int rvwFood;
	double rvwOverall; 
	String rvwComments;
	String hotelId;
	String userId;
	String rvwState;
	public Date getRvwDate() {
		return rvwDate;
	}
	public void setRvwDate(Date rvwDate) {
		this.rvwDate = rvwDate;
	}
	public int getRvwCleaness() {
		return rvwCleaness;
	}
	public void setRvwCleaness(int rvwCleaness) {
		this.rvwCleaness = rvwCleaness;
	}
	public int getRvwService() {
		return rvwService;
	}
	public void setRvwService(int rvwService) {
		this.rvwService = rvwService;
	}
	public int getRvwStaff() {
		return rvwStaff;
	}
	public void setRvwStaff(int rvwStaff) {
		this.rvwStaff = rvwStaff;
	}
	public int getRvwLocation() {
		return rvwLocation;
	}
	public void setRvwLocation(int rvwLocation) {
		this.rvwLocation = rvwLocation;
	}
	public int getRvwMoney() {
		return rvwMoney;
	}
	public void setRvwMoney(int rvwMoney) {
		this.rvwMoney = rvwMoney;
	}
	public int getRvwFood() {
		return rvwFood;
	}
	public void setRvwFood(int rvwFood) {
		this.rvwFood = rvwFood;
	}
	public double getRvwOverall() {
		return rvwOverall;
	}
	public void setRvwOverall(double rvwOverall) {
		this.rvwOverall = rvwOverall;
	}
	public String getRvwComments() {
		return rvwComments;
	}
	public void setRvwComments(String rvwComments) {
		this.rvwComments = rvwComments;
	}
	public String getHotelId() {
		return hotelId;
	}
	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getRvwState() {
		return rvwState;
	}
	public void setRvwState(String rvwState) {
		this.rvwState = rvwState;
	}
	
	
	
	
}
