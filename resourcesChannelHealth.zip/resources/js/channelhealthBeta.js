var channelArray=[];
var statusArray=[];
var mainDataMap = new Object();

var dateTime="";
var endTimeStamp="";

var upCnt=0;
var l4Cnt=0;
var l3Cnt=0;
var l2Cnt=0;
var l1Cnt=0;
var cdCnt=0;
var dnCnt=0;
var totalCnt=0;

function getDataUrlNew(){
	upCnt=0;
	l4Cnt=0;
	l3Cnt=0;
	l2Cnt=0;
	l1Cnt=0;
	cdCnt=0;
	dnCnt=0;
	totalCnt=0;
	
	statusArray=[];
	channelArray=[];
	mainDataMap = new Object();
	var formatted="";	
	var xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {
	    if (xhttp.readyState == 4 && xhttp.status == 200) {
	    	
	    	upCnt=0;
	    	l4Cnt=0;
	    	l3Cnt=0;
	    	l2Cnt=0;
	    	l1Cnt=0;
	    	cdCnt=0;
	    	dnCnt=0;
	    	totalCnt=0;
	    	
	    	var responseTxt = xhttp.responseText;
	    	
	    	var response = responseTxt.replace("[", "");
	    	response = response.replace("]", "");
	    	    	
	    	//console.log("responseTxt ======== "+responseTxt);
	    	//console.log("response length ==== "+response.length);
	    	//console.log("response =========== "+response);
	    	//console.log("=====================================================================");
	    	
	    	var dataList = response.split(",");
	    	MainPageDataArray = dataList;
	    	endTimeStamp = dataList[0].split("#")[1].trim();    	
	    	
	    	dateTime=dataList[0].replace("#"," To ");
	    	
	    	for(var i = 1; i < dataList.length; i++){
	    		var statusID="";
	    		var abbrData="UP";
	    		var paramData=dataList[i].split("|");
	    		var priority=6;
	    		mainDataMap[paramData[0].trim()]=paramData.toString();
	    		channelArray.push(paramData[0].trim());	    		
	    		if(paramData[5].trim() =="UP"){
	    			statusID="status-up";
	    			abbrData="Up";
	    			priority=6;
	    			upCnt++;
	    		}
	    		else if(paramData[5].trim() =="DOWN"){
	    			statusID="status-down";
	    			abbrData="Down";
	    			priority=0;
	    			dnCnt++;
	    		}
	    		else if(paramData[5].trim() =="CD"){
	    			
	    			statusID="status-cd";
	    			abbrData="Degraded";
	    			priority=1;
	    			cdCnt++;
	    		}
	    		else if(paramData[5].trim() =="L4"){
	    			statusID="status-L4";
	    			abbrData="Problematic L4";
	    			priority=5;
	    			l4Cnt++;
	    		}
	    		else if(paramData[5].trim() =="L3"){
	    			statusID="status-L3";
	    			abbrData="Problematic L3";
	    			priority=4;
	    			l3Cnt++;
	    		}
	    		else if(paramData[5].trim() =="L2"){
	    			statusID="status-L2";
	    			abbrData="Problematic L2";
	    			priority=3;
	    			l2Cnt++;
	    		}
	    		else if(paramData[5].trim() =="L1"){
	    			statusID="status-L1";
	    			abbrData="Problematic L1";
	    			priority=2;
	    			l1Cnt++;
	    		}
	    		
	    		statusArray.push(priority+"|"+paramData[0].trim());
	    		
	    		//alert(paramData);
    			var url="/channelhealth/fT/getChannelReqCount/"+paramData[0].trim();
				formatted=formatted+"<div class='Row'><div class='Cell'><p><a id="+paramData[0].trim()+" href='#' onclick=\"getChannelData('"+url+"','"+paramData[0].trim()+"','"+endTimeStamp+"','"+paramData[5].trim()+"','T')\">"+paramData[0]+"</a></p></div><div class='Cell'><p class='count'><abbr title='Total no of Request'>"+paramData[1].trim()+"</abbr> <abbr title='No of Success Request'>"+paramData[2].trim()+"</abbr> <abbr title='No of Error Request'>"+paramData[3].trim()+"</abbr> <abbr title='Error Request Percentage'>"+paramData[4].trim()+"% </abbr></p><abbr id='channel-status' title='"+abbrData+"'><div class='status' id='"+statusID+"'></div></abbr></div></div>";
				totalCnt++;
	    	}
	    	
	    	setCounts(upCnt,l4Cnt,l3Cnt,l2Cnt,l1Cnt,cdCnt,dnCnt,totalCnt);
	    	//document.getElementById("trend-min").value="30";
	    	document.getElementById("timedate").innerHTML=dateTime;
    		document.getElementById("ari-table-data").innerHTML=formatted;
        	
	    }
	  };
	  //showLoading();
	  xhttp.open("GET", "/channelhealth/fT/getARIChannelsReqCount", true);
	  xhttp.send();
}

function refresh(){
	document.getElementById("refresh-dashboard").style.display="block";
	getDataUrlNew();
	document.getElementById("refresh-dashboard").style.display="none";
}
function refreshStates(){
	document.getElementById("refresh-dashboard").style.display="block";
	showStateTrend();
	document.getElementById("refresh-dashboard").style.display="none";
}
function setCounts(upCnt,l4Cnt,l3Cnt,l2Cnt,l1Cnt,cdCnt,dnCnt,totalCnt){
	document.getElementById("upCnt").innerHTML = upCnt;
	document.getElementById("l4Cnt").innerHTML = l4Cnt;
	document.getElementById("l3Cnt").innerHTML = l3Cnt;
	document.getElementById("l2Cnt").innerHTML = l2Cnt;
	document.getElementById("l1Cnt").innerHTML = l1Cnt;
	document.getElementById("cdCnt").innerHTML = cdCnt;
	document.getElementById("dnCnt").innerHTML = dnCnt;
	document.getElementById("totalCnt").innerHTML = "<b>"+totalCnt+"</b>";	
}

function sortAZ(){
	//console.log("MainPageDataArray==="+MainPageDataArray);
	//console.log("MainMap==="+mainDataMap);
	var formatted="";
	channelArray.sort();
	//console.log(channelArray);
	
	for(var i = 0; i < channelArray.length; i++){
		var statusID="";
		var abbrData="UP";
		var paramData=mainDataMap[channelArray[i].trim()].split(",");
		
		//console.log(paramData);
		if(paramData[5].trim() =="UP"){
			statusID="status-up";
			abbrData="Up";
		}
		else if(paramData[5].trim() =="DOWN"){
			statusID="status-down";
			abbrData="Down";
		}
		else if(paramData[5].trim() =="CD"){
			
			statusID="status-cd";
			abbrData="Degraded";
		}
		else if(paramData[5].trim() =="L4"){
			statusID="status-L4";
			abbrData="Problematic L4";
		}
		else if(paramData[5].trim() =="L3"){
			statusID="status-L3";
			abbrData="Problematic L3";
		}
		else if(paramData[5].trim() =="L2"){
			statusID="status-L2";
			abbrData="Problematic L2";
		}
		else if(paramData[5].trim() =="L1"){
			statusID="status-L1";
			abbrData="Problematic L1";
		}
			    		
		//alert(paramData);
		var url="/channelhealth/fT/getChannelReqCount/"+paramData[0].trim();
		formatted=formatted+"<div class='Row'><div class='Cell'><p><a id="+paramData[0].trim()+" href='#' onclick=\"getChannelData('"+url+"','"+paramData[0].trim()+"','"+endTimeStamp+"','"+paramData[5].trim()+"','T')\">"+paramData[0]+"</a></p></div><div class='Cell'><p class='count'><abbr title='Total no of Request'>"+paramData[1].trim()+"</abbr> <abbr title='No of Success Request'>"+paramData[2].trim()+"</abbr> <abbr title='No of Error Request'>"+paramData[3].trim()+"</abbr> <abbr title='Error Request Percentage'>"+paramData[4].trim()+"% </abbr></p><abbr id='channel-status' title='"+abbrData+"'><div class='status' id='"+statusID+"'></div></abbr></div></div>";
		
	}
	
	//console.log(mainDataMap);
	//console.log(channelArray);
	//document.getElementById("trend-min").value="30";
	document.getElementById("timedate").innerHTML=dateTime;
	document.getElementById("ari-table-data").innerHTML=formatted;
		
}

function sortStatus(){
	var formatted="";
	//console.log("statusArray==="+statusArray);
	statusArray.sort();
	//console.log("After sort statusArray==="+statusArray);
	
	for(var i = 0; i < statusArray.length; i++){
		var statusID="";
		var abbrData="UP";
		var priority = statusArray[i].split("|")[0].trim();
		var paramData=mainDataMap[statusArray[i].split("|")[1].trim()].split(",");
		
		//console.log(paramData);
		if(paramData[5].trim() == "UP" && priority == "6"){
			statusID="status-up";
			abbrData="Up";
		}
		else if(paramData[5].trim() =="DOWN" && priority == "0"){
			statusID="status-down";
			abbrData="Down";
		}
		else if(paramData[5].trim() =="CD" && priority == "1"){
			
			statusID="status-cd";
			abbrData="Degraded";
		}
		else if(paramData[5].trim() =="L4" && priority == "5"){
			statusID="status-L4";
			abbrData="Problematic L4";
		}
		else if(paramData[5].trim() =="L3" && priority == "4"){
			statusID="status-L3";
			abbrData="Problematic L3";
		}
		else if(paramData[5].trim() =="L2" && priority == "3"){
			statusID="status-L2";
			abbrData="Problematic L2";
		}
		else if(paramData[5].trim() =="L1" && priority == "2"){
			statusID="status-L1";
			abbrData="Problematic L1";
		}
			    		
		//alert(paramData);
		var url="/channelhealth/fT/getChannelReqCount/"+paramData[0].trim();
		formatted=formatted+"<div class='Row'><div class='Cell'><p><a id="+paramData[0].trim()+" href='#' onclick=\"getChannelData('"+url+"','"+paramData[0].trim()+"','"+endTimeStamp+"','"+paramData[5].trim()+"','T')\">"+paramData[0]+"</a></p></div><div class='Cell'><p class='count'><abbr title='Total no of Request'>"+paramData[1].trim()+"</abbr> <abbr title='No of Success Request'>"+paramData[2].trim()+"</abbr> <abbr title='No of Error Request'>"+paramData[3].trim()+"</abbr> <abbr title='Error Request Percentage'>"+paramData[4].trim()+"% </abbr></p><abbr id='channel-status' title='"+abbrData+"'><div class='status' id='"+statusID+"'></div></abbr></div></div>";
		
	}
	
	//console.log(mainDataMap);
	//console.log(channelArray);
	//document.getElementById("trend-min").value="30";
	document.getElementById("timedate").innerHTML=dateTime;
	document.getElementById("ari-table-data").innerHTML=formatted;
	
}

function getChannelData(url,channelName,endTimeStamp,status,pageFlag){
	document.getElementById("dashboard-data").value = url+"|"+channelName+"|"+endTimeStamp+"|"+status;
	document.getElementById("channel-name").innerHTML= channelName.trim(); 
	
	//document.getElementById("ari-property-data").style.display="none";
	document.getElementById("channel-keys").style.display="none";
	
	var trendMin="30";
	if(pageFlag == "T"){
		trendMin="30";
		document.getElementById("trend-min").value=trendMin;
	}else{
		trendMin=document.getElementById("trend-min").value;
	}
	
	
	
	//alert(trendMin);
    url=url+"/"+trendMin+"/"+endTimeStamp;
	//alert("Url====="+url);

	var xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {
	    if (xhttp.readyState == 4 && xhttp.status == 200) {
	    	res = xhttp.responseText;
	    	//alert(res);
	    	var response = res.replace("[", "");
	    	response = response.replace("]", "");
	    	var dataList=response.split("#");
	    	try{
	    		colChartTrend(dataList[0],channelName);
	    	}catch(err){
	    		
	    	}
	    	try{
	    		channelAdvisoryData(dataList[1],channelName,status);
	    	}catch(err){
	    		
	    	}
	    	try{
	    		thresholdChartTrend(dataList[2],channelName);
	    	}catch(err){
	    		
	    	}    	
	    	
	    }
	  };
	  xhttp.open("GET", url, true);
	  xhttp.send();
}

function colChartTrend(data,channelName){
	data=data.replace("[","");
	data=data.replace("]","");
	//alert("colChartTrend -----"+data);
	
	//console.log("colChartTrend====="+data+"===");
	var dataSet=data.trim().split(",");
	//console.log("dataSet.length====="+dataSet.length);
	var currDate="";
	if(data.trim() != "" || dataSet.length != 0){
		currDate=dataSet[0].split("|")[0].trim().split(" ")[0];	
		var mainArrResv = [['Date','Total Req','Err Req']];
	  	var trendMin=document.getElementById("trend-min").value;
		for (var i = 0; i < dataSet.length; i++) {
			var param=dataSet[i].split("|");
			var childArr = new Array();
			childArr[0] = param[0].trim().split(" ")[1];
			childArr[1] = parseInt(param[1].trim());
			childArr[2] = parseInt(param[2].trim());	
			
			mainArrResv.push(childArr);
		}
		//alert(mainArrResv[0]);
		var data = google.visualization.arrayToDataTable(mainArrResv);
		var options = {
				title: 'Trend Analysis of '+channelName+' for last '+trendMin+" Minutes",
				hAxis : { 
			        textStyle : {
			            fontSize: 12 // or the number you want
			        },
			        slantedText:true,
			        slantedTextAngle:45
			    },
			    vAxis : { 
			        textStyle : {
			            fontSize: 12 // or the number you want
			        },
			        gridlines: { 
			        	count: 8,
			        }
			    }
	    };
	   document.getElementById("ari-channels").style.display="none";
	   try {
		   document.getElementById("side-window").style.display="none";
	   } catch (e) {
		   //exception for side-window which not exist for new State Dashboard
	   }
	   document.getElementById("main-window").style.width="100%";
	   document.getElementById("ari-analytic").style.display="block";
	   var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
	   
	   function selectHandler() {
	          var selectedItem = chart.getSelection()[0];
	          
	          if (selectedItem) {
	        	  	var formatted="";
		            var time = data.getValue(selectedItem.row, 0);
		            var datetime=currDate+" "+time;
		            //alert('The user selected ' + datetime);
		            
		            var xhttp = new XMLHttpRequest();
		            xhttp.onreadystatechange = function() {
		            	if (xhttp.readyState == 4 && xhttp.status == 200) {
			      	    	var responseTxt = xhttp.responseText;
			      	    	
			      	    	var response = responseTxt.replace("[", "");
			      	    	response = response.replace("]", "");
			      	    	//console.log("Channel Response"+response);
			      	    	var dataList = response.split(",");
			      	    	var exceptionList=[];
			      	    	for(var i = 0; i < dataList.length; i++){
			    	    		var paramData=dataList[i].split("|");
			    	    		var showID="status-N";
			    	    		if(paramData[0].trim() == "E"){
			    	    			showID="status-E";
			    	    			//console.log(paramData[3].trim());
			    	    			/*if(exceptionList.indexOf(paramData[3].trim()) == -1){
			    	    				exceptionList.push("'"+paramData[3].trim()+"'");
			    	    			}*/
			    	    			if(exceptionList.indexOf("'"+paramData[3].trim()+"'") == -1){
			    	                    exceptionList.push("'"+paramData[3].trim()+"'");
			    	                   }
			    	    		}
			    	    		
			    	    		//Live=====
			    	    		var logUrl="http://ec2-52-3-127-82.compute-1.amazonaws.com:8080/alertgui/rest/detailLogData/Allocator/"+paramData[3].trim()+"/"+paramData[2].trim()+"/"+paramData[4].trim(); 
			    	    		
			    	    		//PP=======[href="/alertgui/rest/detailLogData/Allocator/Gloria Hotel Dubai/Expedia-XML/2016-Sep-19 07:18:24"]
			    	    		//var logUrl="http://172.16.4.88:18080/alertgui/rest/detailLogData/Allocator/"+paramData[3].trim()+"/"+paramData[2].trim()+"/"+paramData[4].trim();
			    				
			    	    		formatted=formatted+"<div class='Row' id='"+showID+"'><div class='Cell'><p>"+paramData[3].trim()+"</p></div><div class='Cell'><p class='count'><a href='"+logUrl+"' target='_blank'>"+paramData[4].trim()+"</a></p></div></div>";
			    	    		
			      	    	}
			      	    				      	    	
			      	    	document.getElementById("chart-threshold").style.display="none";
			      	    	document.getElementById("channel-keys").style.display="block";
			      	    	//document.getElementById("ari-property-data").style.display="block";
			      	    	document.getElementById("ari-property-data").innerHTML=formatted;
			      	    	
			      	    	console.log("Property Exception List =>"+exceptionList);
			      	    	
		            	}
		            };
		            var url="/channelhealth/fT/get_channel_count_detail/"+channelName+"/"+datetime;
		            xhttp.open("GET", url, true);
		      	  	xhttp.send();
	          }
	    }
	   
	   google.visualization.events.addListener(chart, 'select', selectHandler);
	   
	   
	   chart.draw(data, options);
	}
}

function channelAdvisoryData(data,channelName,status){
	document.getElementById("cd-header-data").innerHTML="No Data Found";
	document.getElementById("channel-cd-data").innerHTML="";
	data=data.replace("[","");
	data=data.replace("]","");
	data=data.replace("{","");
	data=data.replace("}","");
	//console.log("channelAdvisoryData====="+data+"======");
	
	var formatted="";
	var dataSet=data.trim().split(",");
	var channelName="";
	var behavior=""
	//console.log("dataSet.length====="+dataSet.length);
	if(status.trim() =="CD"){
		if(data.trim() != "" || dataSet.length != 0){
			
			if(dataSet.length != 0){
				channelName=dataSet[0].split("|")[0].trim();
				behavior=dataSet[0].split("|")[1].trim();
			}
			for (var i = 0; i < dataSet.length; i++) {
				var param=dataSet[i].split("|");
				var paramData=param[2].split("=");
				formatted=formatted+"<div class='Row'><div class='Cell'><p class='status-name'>"+paramData[0].trim()+"</p></div><div class='Cell'><p class='state'>"+paramData[1].trim()+"</p></div></div>";
		
			}
			
			document.getElementById("cd-header-data").innerHTML=channelName+" | "+behavior;
			document.getElementById("channel-cd-data").innerHTML=formatted;
		}
	}else{
		document.getElementById("cd-header-data").innerHTML="No Data Found";
	}
	
}
function thresholdChartTrend(data,channelName){
	data=data.replace("[","");
	data=data.replace("]","");
	
	
	
	//console.log("thresholdChartTrend====="+data+"=======");
	//alert("colChartTrend -----"+data);
	var dataSet=data.trim().split(",");
	//console.log("dataSet.length====="+dataSet.length);
  	if(data.trim() != "" || dataSet.length != 0){
  		
  		var mainArrResv = [['Date','Threshold']];
	  	//var trendMin=document.getElementById("trend-min").value;
		for (var i = 0; i < dataSet.length; i++) {
			var param=dataSet[i].split("|");
			var childArr = new Array();
			childArr[0] = param[0].trim().split(" ")[1];
			childArr[1] = parseInt(param[1].trim());
			mainArrResv.push(childArr);
		}
		var data = google.visualization.arrayToDataTable(mainArrResv);
		var options = {
				title: 'Threshold Trend of '+channelName+' for last 5 Hours',
				hAxis : { 
			        textStyle : {
			            fontSize: 12 // or the number you want
			        },
			        slantedText:true,
			        slantedTextAngle:45
			    },
			    vAxis : { 
			        textStyle : {
			            fontSize: 12 // or the number you want
			        },
			        gridlines: { 
			        	count: 8,
			        }
			    }
	    };
	   //document.getElementById("ari-channels").style.display="none";
		document.getElementById("chart-threshold").style.display="block";
	   var chart = new google.visualization.LineChart(document.getElementById('chart-threshold'));
	   chart.draw(data, options);	
  	}
}

function getStatus(){
		
	var time="";
	var xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {
	    if (xhttp.readyState == 4 && xhttp.status == 200) {
	    	res = xhttp.responseText;
	    	//console.log("loadDataRes Hitting===========>>>>>"+res);
	    	res=res.replace("[\"","");
	      	res=res.replace("\"]","");
	      	//res=res.replace("\"","");
	      	//console.log("loadDataRes Hitting===========>>>>>"+res);
		  	var dataSet = res.split(",");
		  	for (var i = 0; i < dataSet.length; i++) {
		  		var paramData=dataSet[i].split("|");
		  		time=paramData[0].trim();
		  		formatted=formatted+"<div class='Row' id='data-row'><div class='Cell'><p>"+paramData[1]+"</p></div><div class='Cell'><p class='count'>"+paramData[2]+"</p></div></div>";
		  		
		  	}
		  	
		  	document.getElementById("timedate").innerHTML=time;
    		document.getElementById("ari-table-data").innerHTML=formatted;
	    }
	  };
	  //showLoading();
	  xhttp.open("GET", "/channelhealth/fT/getStatus", true);
	  xhttp.send();
}
function homeWindow(){
	document.getElementById("ari-channels").style.display="block";
	document.getElementById("ari-analytic").style.display="none";
	document.getElementById("side-window").style.display="block";
	document.getElementById("main-window").style.width="75%";
}
function callThrend(){
	var data=document.getElementById("dashboard-data").value;
	var dataSet=data.split("|");
	if(dataSet.length == 4){
		getChannelData(dataSet[0].trim(), dataSet[1].trim(), dataSet[2].trim(), dataSet[3].trim(),"F");
	}
	
}

function showStateTrend(){
	upCnt=0;
	l4Cnt=0;
	l3Cnt=0;
	l2Cnt=0;
	l1Cnt=0;
	cdCnt=0;
	dnCnt=0;
	totalCnt=0;
	
	statusArray=[];
	channelArray=[];
	mainDataMap = new Object();
	
	var formatted="";
	var detailFormatted="";
	
	var xhttp = new XMLHttpRequest();
	  xhttp.onreadystatechange = function() {
	    if (xhttp.readyState == 4 && xhttp.status == 200) {
	    	
	    	
	    	var responseTxt = xhttp.responseText;
	    	var response = responseTxt.replace("[", "");
	    	response = response.replace("]", "");
	    	    	
	    	//console.log("responseTxt ======== "+responseTxt);
	    	//console.log("response length ==== "+response.length);
	    	//console.log("response =========== "+response);
	    	//console.log("=====================================================================");
	    	
	    	var dataSetList=response.split("@");
	    	
	    	for(var j = (dataSetList.length - 1); j > 0; j--){
	    		
	    		var dataList = dataSetList[j].split(",");
		    	MainPageDataArray = dataList;
		    	endTimeStamp = dataList[0].split("#")[1].trim();
		    	
		    	dateTime=dataList[0].replace("#"," To ");
		    	formatted="";
		    	upCnt=0;
		    	l4Cnt=0;
		    	l3Cnt=0;
		    	l2Cnt=0;
		    	l1Cnt=0;
		    	cdCnt=0;
		    	dnCnt=0;
		    	totalCnt=0;
		    	for(var i = 1; i < dataList.length; i++){
		    		var statusID="";
		    		var abbrData="UP";
		    		var paramData=dataList[i].split("|");
		    		var priority=6;
		    		
		    		mainDataMap[paramData[0].trim()]=paramData.toString();
		    		channelArray.push(paramData[0].trim());
		    		
		    		if(paramData[5].trim() =="UP"){
		    			statusID="status-up";
		    			abbrData="Up";
		    			priority=6;
		    			upCnt++;
		    		}
		    		else if(paramData[5].trim() =="DOWN"){
		    			statusID="status-down";
		    			abbrData="Down";
		    			priority=0;
		    			dnCnt++;
		    		}
		    		else if(paramData[5].trim() =="CD"){
		    			statusID="status-cd";
		    			abbrData="Degraded";
		    			priority=1;
		    			cdCnt++;
		    		}
		    		else if(paramData[5].trim() =="L4"){
		    			statusID="status-L4";
		    			abbrData="Problematic L4";
		    			priority=5;
		    			l4Cnt++;
		    		}
		    		else if(paramData[5].trim() =="L3"){
		    			statusID="status-L3";
		    			abbrData="Problematic L3";
		    			priority=4;
		    			l3Cnt++;
		    		}
		    		else if(paramData[5].trim() =="L2"){
		    			statusID="status-L2";
		    			abbrData="Problematic L2";
		    			priority=3;
		    			l2Cnt++;
		    		}
		    		else if(paramData[5].trim() =="L1"){
		    			statusID="status-L1";
		    			abbrData="Problematic L1";
		    			priority=2;
		    			l1Cnt++;
		    		}
		    		
		    		statusArray.push(priority+"|"+paramData[0].trim());
		    		
		    		//alert(paramData);
	    			var url="/channelhealth/fT/getChannelReqCount/"+paramData[0].trim();
					formatted=formatted+"<div class='Row' id='"+paramData[0].trim()+"'><div class='Cell'><p><a href='#' onclick=\"getChannelData('"+url+"','"+paramData[0].trim()+"','"+endTimeStamp+"','"+paramData[5].trim()+"','T')\">"+paramData[0]+"</a></p></div><div class='Cell'><p class='count'><abbr title='Total no of Request'>"+paramData[1].trim()+"</abbr> <abbr title='No of Success Request'>"+paramData[2].trim()+"</abbr> <abbr title='No of Error Request'>"+paramData[3].trim()+"</abbr> <abbr title='Error Request Percentage'>"+paramData[4].trim()+"% </abbr></p><abbr id='channel-status' title='"+abbrData+"'><div class='status' id='"+statusID+"'></div></abbr></div></div>";
					totalCnt++;
					
		    	}//=====end loop i
		    	var counts="<b>T:"+totalCnt+"</b> UP:"+upCnt+" L4:"+l4Cnt+" L3:"+l3Cnt+" L2:"+l2Cnt+" L1:"+l1Cnt+" CD:"+cdCnt+" DN:"+dnCnt;
		    	detailFormatted=detailFormatted+"<div class='state-tab-data' id='"+endTimeStamp+"'><div class='interval-time' id='"+dateTime+"'>"+dateTime+"</div><div class='counts' id='channel-counts'>"+counts+"</div><div class='Table' id='table-title'><div class='Heading'><div class='Cell'><p><a href='javascript:void(0);' >Channel Name</a></p></div><div class='Cell'><p><a href='javascript:void(0)'>Status</a></p></div></div></div><div class='Table' id='ari-table-data'>"+formatted+"</div></div>";
	    	}//=====end loop j
	    		    	
	    	
	    	//console.log(mainDataMap);
	    	//console.log(channelArray);
	    	//document.getElementById("trend-min").value="30";
	    	//var cntData="Channel Counts >> Total : "+totalCnt+" &nbsp;>>&nbsp; Up : "+upCnt+" &nbsp;>>&nbsp; L4 : "+l4Cnt+" &nbsp;>>&nbsp; L3 : "+l3Cnt+" &nbsp;>>&nbsp; L2 : "+l2Cnt+" &nbsp;>>&nbsp; L1 : "+l1Cnt+" &nbsp;>>&nbsp; Degraded : "+cdCnt+" &nbsp;>>&nbsp; Down : "+dnCnt;
	    	
	    	//setCounts(upCnt,l4Cnt,l3Cnt,l2Cnt,l1Cnt,cdCnt,dnCnt,totalCnt);
	    	//document.getElementById("channel-count").innerHTML=cntData;
	    	//document.getElementById("timedate").innerHTML="Base Timestamp : "+dateTime;
    		document.getElementById("state-trend").innerHTML=detailFormatted;
        	
	    }
	  };
	  //showLoading();
	  xhttp.open("GET", "/channelhealth/fT/get_channelhealth_state", true);
	  xhttp.send();
}

function mainWindow(){
	document.getElementById("ari-channels").style.display="block";
	document.getElementById("ari-analytic").style.display="none";
	document.getElementById("main-window").style.width="99%";
}

/*function highLightChannel(className,channelName){
	console.log("highLightChannel method=="+channelName);
	var elems = document.getElementsByClassName(className);
	
	alert(elems.length);
	
	for (var i=0;i<elems.length;i++){
		
	   if(elems[i].id != channelName.trim()){
		   //elems[i].style.removeProperty("background-color");
		   
	   }else{
		   console.log("value of i"+i);
		   document.getElementById(elems[i].id).style.backgroundColor="#b3d9ff";
		   //elems[i].id.style.backgroundColor="#b3d9ff";
	   }
	  
	}
		
	
}*/


